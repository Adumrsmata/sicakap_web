
'use server';
/**
 * @fileOverview An AI agent that analyzes uploaded staffing documents and answers questions about their content.
 *
 * - aiDocumentAnalysis - A function that handles the document analysis process.
 * - AIDocumentAnalysisInput - The input type for the aiDocumentAnalysis function.
 * - AIDocumentAnalysisOutput - The return type for the aiDocumentAnalysis function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AIDocumentAnalysisInputSchema = z.object({
  fileDataUri: z
    .string()
    .describe(
      "The staffing document to be analyzed, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  question: z.string().describe("The user's question about the document's content."),
});
export type AIDocumentAnalysisInput = z.infer<typeof AIDocumentAnalysisInputSchema>;

const AIDocumentAnalysisOutputSchema = z.object({
  answer: z.string().describe("The AI's answer based on the document content."),
});
export type AIDocumentAnalysisOutput = z.infer<typeof AIDocumentAnalysisOutputSchema>;

export async function aiDocumentAnalysis(input: AIDocumentAnalysisInput): Promise<AIDocumentAnalysisOutput> {
  return aiDocumentAnalysisFlow(input);
}

const aiDocumentAnalysisPrompt = ai.definePrompt({
  name: 'aiDocumentAnalysisPrompt',
  input: { schema: AIDocumentAnalysisInputSchema },
  output: { schema: AIDocumentAnalysisOutputSchema },
  prompt: `Kamu adalah SiCakap, asisten virtual kepegawaian RS Mata Bali Mandara yang profesional, ramah, dan sangat teliti.

Tugasmu adalah menganalisis dokumen kepegawaian yang diunggah oleh pegawai (seperti SK Pangkat, SK Jabatan, Ijazah, dll) dan menjawab pertanyaan mereka berdasarkan isi dokumen tersebut.

INFORMASI PENTING (NARAHUBUNG):
Jika dokumen menunjukkan kebutuhan konsultasi lebih lanjut, arahkan ke admin berikut:
1. Kenaikan Pangkat Fungsional, Tugas Belajar, Karis/Karsu, Pensiun, Gelar, Model C, SLKS:
   Admin: I Nyoman Jaya Merta ([Hubungi WhatsApp](https://wa.me/6287862206937))

2. Kenaikan Pangkat (Reguler), SI-ASN:
   Admin: Ni Nyoman Suwari ([Hubungi WhatsApp](https://wa.me/62895601305041))

3. Cuti, KGB/TPP, Surat Tugas, E-Cuti:
   Admin: Santy Pattawari ([Hubungi WhatsApp](https://wa.me/6285337812997))

4. SIMPEG/SIPERI:
   Admin: Shri Padmayani ([Hubungi WhatsApp](https://wa.me/6282257607892))

5. SISDMK, Ukom JFK, SPMT:
   Admin: Gede Mahendra Arya Wiguna Pangestu ([Hubungi WhatsApp](https://wa.me/6282138740446))

INSTRUKSI:
- Analisis dokumen yang diberikan: {{media url=fileDataUri}}
- Jawab pertanyaan: "{{{question}}}"
- Gunakan Bahasa Indonesia yang sopan dan profesional.
- Jika dokumen tidak terbaca atau tidak berkaitan dengan kepegawaian, sampaikan dengan ramah bahwa kamu hanya bisa menganalisis dokumen terkait SDM/Kepegawaian.
- Hubungkan temuan di dokumen dengan aturan kepegawaian (seperti masa kerja, periode pangkat, dll) jika relevan.
- Berikan jawaban yang terstruktur dengan poin-poin agar mudah dipahami.`,
});

const aiDocumentAnalysisFlow = ai.defineFlow(
  {
    name: 'aiDocumentAnalysisFlow',
    inputSchema: AIDocumentAnalysisInputSchema,
    outputSchema: AIDocumentAnalysisOutputSchema,
  },
  async (input) => {
    const { output } = await aiDocumentAnalysisPrompt(input);
    return output!;
  }
);
