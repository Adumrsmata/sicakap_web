export type MessageRole = 'user' | 'bot';

export interface ChatMessage {
  role: MessageRole;
  content: string;
  timestamp: string;
  file_url?: string;
  file_name?: string;
}

export interface UserIdentity {
  nama: string;
  nip: string;
}

export interface KnowledgeItem {
  keywords: string[];
  answer: string;
}

const ADMINS = {
  JAYA: { nama: 'I Nyoman Jaya Merta', wa: '087862206937' },
  SUWARI: { nama: 'Ni Nyoman Suwari', wa: '0895601305041' },
  SANTY: { nama: 'Santy Pattawari', wa: '085337812997' },
  SHRI: { nama: 'Shri Padmayani', wa: '082257607892' },
  GEDE: { nama: 'Gede Mahendra Arya Wiguna Pangestu', wa: '082138740446' },
};

const contactInfo = (admin: { nama: string; wa: string }) => {
  const waLink = `https://wa.me/${admin.wa.replace(/[^0-9]/g, '').replace(/^0/, '62')}`;
  return `\n\nUntuk konsultasi lebih lanjut mengenai layanan ini, silakan hubungi petugas kami:\n\n👤 **${admin.nama}**\n📱 WhatsApp: [Hubungi via WhatsApp](${waLink})`;
};

export const KNOWLEDGE_BASE: KnowledgeItem[] = [
  // Group 2: Ni Nyoman Suwari (SUWARI) - Kenaikan Pangkat
  {
    keywords: ['kenaikan pangkat', 'layanan kenaikan pangkat', 'pangkat reguler', 'pangkat struktural'],
    answer: `Berikut informasi lengkap mengenai layanan Kenaikan Pangkat yang perlu Bapak/Ibu ketahui:

📅 **Periode Kenaikan Pangkat** (Berdasarkan Surat Deputi Nomor 13749/B-MP.01.01/SD/D/2025). Kenaikan Pangkat dapat diproses 12 (dua belas) kali dalam setahun:

| No | Periode | Submit Usulan / Approval |
|:---:|:---|:---|
| 1 | Januari | 16 November s/d 15 Desember |
| 2 | Februari | 16 Desember s/d 15 Januari |
| 3 | Maret | 16 Januari s/d 15 Februari |
| 4 | April | 16 Februari s/d 15 Maret |
| 5 | Mei | 16 Maret s/d 15 April |
| 6 | Juni | 16 April s/d 15 Mei |
| 7 | Juli | 16 Mei s/d 15 Juni |
| 8 | Agustus | 16 Juni s/d 15 Juli |
| 9 | September | 16 Juli s/d 15 Agustus |
| 10 | Oktober | 16 Agustus s/d 15 September |
| 11 | November | 16 September s/d 15 Oktober |
| 12 | Desember | 16 Oktober s/d 15 November |

*Catatan: Pengusulan ke Kepegawaian ditutup H-7 dari batas akhir periodisasi di atas.*

**1. Kenaikan Pangkat Reguler/Struktural**
Syarat Umum:
a. SKP 2 tahun terakhir
b. SK Pangkat Terakhir
c. SK Jabatan Terakhir + Pertek (serta peta jabatan bila pangkat puncak)

**2. Kenaikan Pangkat Fungsional**
Syarat Umum:
a. SKP 2 tahun terakhir dan atau sampai terpenuhinya angka kredit
b. SK Pangkat Terakhir
c. SK Jabatan Fungsional Terakhir
d. Sertifikat Uji Kompetensi (bila naik jenjang/pangkat puncak)
e. Penilaian Angka Kredit (PAK) kumulatif
f. Ijazah dan transkrip (bila ada pencantuman gelar)
g. Pencantuman Gelar

Semoga informasi ini membantu Bapak/Ibu dalam mempersiapkan proses Kenaikan Pangkat dengan lancar!${contactInfo(ADMINS.SUWARI)}`,
  },

  // Group 1: I Nyoman Jaya Merta (JAYA)
  {
    keywords: ['fungsional', 'kenaikan pangkat fungsional', 'jabfung', 'kenaikan jabatan fungsional'],
    answer: `Halo! Selamat datang di SiCakap 😊\n\nBerikut informasi lengkap mengenai layanan Kenaikan Jenjang Fungsional yang perlu Bapak/Ibu ketahui:\n\n**Syarat Umum Pengusulan Kenaikan Jenjang Fungsional:**\na. SKP 2 tahun terakhir dan atau sampai terpenuhinya nilai angka kredit untuk kenaikan pangkat\nb. SK Pangkat Terakhir\nc. SK Jabatan Fungsional Terakhir\nd. Sertifikat Uji Kompetensi\ne. Penilaian Angka Kredit (PAK) dari nilai PAK pangkat terakhir s.d tercukupinya nilai angka kredit yang dipergunakan untuk kenaikan pangkat .\nf. Ijasah dan trankrip (bila ada pencantuman gelar)\ng. Pencantuman Gelar\n\n**Semua dokumen diupload pada aplikasi SIMPEG.**\n\nSemoga informasi ini membantu Bapak/Ibu dalam mempersiapkan proses Kenaikan Jenjang Fungsional dengan lancar!${contactInfo(ADMINS.JAYA)}`,
  },
  {
    keywords: ['tugas belajar', 'kuliah', 'sekolah', 'izin belajar'],
    answer: `Hello bpk/ibu PNS Asisten Virtual Kepegawaian RS Mata Bali Mandara! Menjawab pertanyaan Bapak/ibu tentang **SYARAT TUGAS BELAJAR**.\n\nDalam mendukung transformasi SDM Aparatur melalui percepatan peningkatan kapasitas PNS berbasis kompetensi, pengembangan PNS dilakukan melalui jalur pendidikan dalam bentuk tugas belajar yang selektif, objektif, efisien, akuntabel, dan transparan.\n\n**1. Syarat Umum Biaya Mandiri (Tidak Meninggalkan Tugas):**\na. Memiliki masa kerja minimum 1 tahun sejak diangkat sebagai PNS.\nb. Permohonan ybs ditujukan kepada Kepala Unit Kerja.\nc. Permohonan Kepala Unit Kerja ditujukan kepada Gubernur Bali cq. Kepala BKPSDM Provinsi Bali.\nd. Surat Rekomendasi dari Kepala Unit Kerja.\ne. Surat Pernyataan bermaterai (Rp 10.000) yang isinya:\n   • Tidak pernah/sedang menjalani hukuman disiplin tingkat sedang/berat.\n   • Tidak pernah melanggar kode etik tingkat sedang/berat.\n   • Tidak sedang menjalani pemberhentian sementara.\n   • Tidak akan menuntut penyesuaian ijazah kecuali formasi mengizinkan.\nf. Dokumen: SK CPNS, SK PNS, SK Pangkat terakhir dan SKP 2 tahun terakhir.\ng. SK Jabatan/Fungsional terakhir bagi yang menjabat.\nh. Ijazah dan transkrip nilai terakhir.\ni. Surat Keterangan Kampus & Akreditasi Prodi (Minimal B/Baik Sekali).\nj. Berkas diajukan ke BKPSDM Provinsi Bali sebelum melaksanakan perkuliahan.\n\n**2. Syarat Biaya Mandiri/Beasiswa (Meninggalkan Tugas):**\n- Persyaratan sama dengan di atas.\n- **Tambahan:** Mengajukan surat permohonan pemberhentian dari Jabatan Fungsional (Bagi pejabat fungsional).${contactInfo(ADMINS.JAYA)}`,
  },
  {
    keywords: ['karis', 'karsu', 'kartu istri', 'kartu suami'],
    answer: `Hello bpk/ibu PNS Asisten Virtual Kepegawaian RS Mata Bali Mandara! Menjawab pertanyaan Bapak/ibu tentang:\n\n**SYARAT PENGAJUAN KARIS/ KARSU**\n\nPengajuan usulan Karis/karsu Pegawai dapat diajukan pada **My ASN**. Dengan melakukan peremajaan pada data pada Menu **Riwayat Keluarga** (Pasangan, Anak, dan Orang Tua) dengan melengkapi:\n1. Akte Perkawinan\n2. Kartu Keluarga\n\nSetelah dilakukan verifikasi oleh BKN baru masuk ke menu Karis /Karsu dengan menyiapkan foto pasangan dan diupload. Maka Karis Karsu sudah terbit.${contactInfo(ADMINS.JAYA)}`,
  },
  {
    keywords: ['pensiun', 'usulan pensiun', 'purna tugas', 'bup'],
    answer: `Hello bpk/ibu PNS Asisten Virtual Kepegawaian RS Mata Bali Mandara! Menjawab pertanyaan Bapak/ibu tentang:\n\n**A. SYARAT PENGAJUAN USUL PENSIUN**\n\nDokumen yang harus dipersiapkan dan diupload pada aplikasi SIMPEG antara lain :\n1. Daftar Perorangan Calon Penerima Pensiun (DPCP) disiapkan Kepeg.\n2. Surat Pernyataan Tidak Dijatuhi HD tingkat Sedang/Berat 1 Tahun terakhir disiapkan Kepeg.\n3. Surat Pernyataan Tidak sedang Menjalani Pidana/Pernah Dipidana disiapkan Kepeg.\n4. SK Pangkat Terakhir.\n5. SK CPNS\n6. SKP 1 tahun terakhir dengan nilai Minimal Baik.\n7. SK Pengangkatan pertama dalam jabatan fungsional/fungsional Utama (Bagi Pejabat Fungsional)\n8. SK Kenaikan Pangkat Penyesuaian Ijasah (Bila memiliki).\n9. SK Pengangkatan, Pemindahan dan Pemberhentian Jabatan (Bila memiliki).\n10. CLTN (Cuti di Luar Tanggungan Negara) dan Pengaktifannya (Bila memiliki).\n11. SK Pemberhentian Sementara.${contactInfo(ADMINS.JAYA)}`,
  },
  {
    keywords: ['gelar', 'pencantuman gelar', 'ijazah baru'],
    answer: `Hello bpk/ibu PNS Asisten Virtual Kepegawaian RS Mata Bali Mandara! Menjawab pertanyaan Bapak/ibu tentang:\n\n**SYARAT PENGAJUAN PENCANTUMAN GELAR**\n\nDokumen yang harus dipersiapkan dan dikirim ke Kepeg :\n1. SK CPNS\n2. SK PNS\n3. SK Pangkat Terakhir\n4. Asli Ijasah dan Transkrip Nilai yang akan diusulkan pencantuman gelarnya .${contactInfo(ADMINS.JAYA)}`,
  },
  {
    keywords: ['model c', 'berhenti', 'pmh'],
    answer: `**Layanan Administrasi Model C**\n\nLayanan terkait surat keterangan pemberhentian atau perpindahan status kepegawaian tertentu sesuai dengan regulasi kepegawaian pemerintah.\n\nUntuk detail spesifik mengenai kasus Model C Bapak/Ibu, silakan hubungi admin kami.${contactInfo(ADMINS.JAYA)}`,
  },
  {
    keywords: ['slks', 'satya lencana', 'penghargaan', '10 tahun', '20 tahun', '30 tahun'],
    answer: `**Layanan Satyalancana Karya Satya (SLKS)**\n\nPengusulan tanda kehormatan dari Presiden RI bagi PNS yang telah menunjukkan kesetiaan dan pengabdian selama 10, 20, atau 30 tahun.\n\n**Kriteria:**\n* Bekerja secara terus menerus tanpa terputus.\n* Tidak pernah dijatuhi hukuman disiplin tingkat sedang atau berat.${contactInfo(ADMINS.JAYA)}`,
  },

  // Group 2 Extra: Ni Nyoman Suwari (SUWARI)
  {
    keywords: ['si-asn', 'siasn', 'bkn', 'pdm'],
    answer: `**Layanan SI-ASN (Sistem Informasi ASN)**\n\nTerkait update data mandiri, perbaikan data profil BKN, atau kendala akses pada platform SI-ASN.\n\nJika Bapak/Ibu mengalami kendala login atau perbedaan data antara SIMPEG dan BKN, silakan konsultasikan dengan admin kami.${contactInfo(ADMINS.SUWARI)}`,
  },

  // Group 3: Santy Pattawari (SANTY)
  {
    keywords: ['cuti pegawai', 'izin cuti', 'cuti tahunan', 'cuti sakit'],
    answer: `**Layanan Cuti Pegawai**\n\nPengelolaan berbagai jenis cuti sesuai Peraturan BKN Nomor 7 Tahun 2021.\n\n**Jenis Cuti:**\n1. Cuti Tahunan (12 hari kerja).\n2. Cuti Besar.\n3. Cuti Sakit.\n4. Cuti Melahirkan.\n5. Cuti Karena Alasan Penting (CAP).\n\nPengajuan wajib melalui atasan langsung sebelum diteruskan ke bagian Kepegawaian.${contactInfo(ADMINS.SANTY)}`,
  },
  {
    keywords: ['kgb', 'tpp', 'berkala', 'tunjangan'],
    answer: `**Layanan Kenaikan Gaji Berkala (KGB) & TPP**\n\n1. **KGB:** Penyesuaian gaji pokok setiap 2 tahun sekali jika memenuhi syarat prestasi kerja.\n2. **TPP:** Administrasi terkait Tambahan Penghasilan Pegawai berdasarkan disiplin dan kinerja.\n\nPastikan data absensi dan capaian kinerja Bapak/Ibu selalu terupdate untuk kelancaran proses ini.${contactInfo(ADMINS.SANTY)}`,
  },
  {
    keywords: ['surat tugas', 'st', 'perjalanan dinas'],
    answer: `**Layanan Penerbitan Surat Tugas**\n\nAdministrasi resmi untuk menugaskan pegawai dalam rangka pendidikan, pelatihan, rapat koordinasi, atau kegiatan rumah sakit di luar tugas rutin.\n\nHarap melampirkan surat undangan atau nota dinas disposisi pimpinan saat pengajuan.${contactInfo(ADMINS.SANTY)}`,
  },
  {
    keywords: ['e-cuti', 'aplikasi cuti', 'cara cuti online'],
    answer: `**Layanan E-Cuti**\n\nBantuan teknis dan administrasi penggunaan aplikasi E-Cuti mandiri untuk transparansi dan efisiensi pengajuan izin secara digital.\n\nJika Bapak/Ibu menemui kendala teknis pada aplikasi, tim kami siap membantu.${contactInfo(ADMINS.SANTY)}`,
  },

  // Group 4: Shri Padmayani (SHRI)
  {
    keywords: ['simpeg', 'siperi', 'update data internal'],
    answer: `**Layanan SIMPEG / SIPERI**\n\nLayanan pengelolaan Sistem Informasi Manajemen Pegawai internal RS Mata Bali Mandara.\n\nBapak/Ibu wajib memastikan data pribadi, data keluarga, and riwayat pekerjaan di SIMPEG sudah sesuai dengan kondisi terbaru.${contactInfo(ADMINS.SHRI)}`,
  },

  // Group 5: Gede Mahendra Arya Wiguna Pangestu (GEDE)
  {
    keywords: ['sisdmk', 'kemenkes', 'nakes'],
    answer: `**Layanan SISDMK (Sistem Informasi SDM Kesehatan)**\n\nUpdate data tenaga kesehatan pada portal Kementerian Kesehatan. Data ini sangat penting sebagai dasar perhitungan kebutuhan nakes dan insentif dari pusat.\n\nPastikan STR dan SIP Bapak/Ibu sudah terinput dengan benar.${contactInfo(ADMINS.GEDE)}`,
  },
  {
    keywords: ['uji kompetensi', 'jfk', 'ukom', 'naik jenjang'],
    answer: `**Layanan Uji Kompetensi JFK**\n\nFasilitasi bagi Pejabat Fungsional Kesehatan yang akan naik jenjang jabatan (misal: Terampil ke Mahir, atau Ahli Pertama ke Ahli Muda).\n\nKami membantu verifikasi berkas portofolio dan pendaftaran ukom pada periode yang tersedia.${contactInfo(ADMINS.GEDE)}`,
  },
  {
    keywords: ['spmt', 'pernyataan tugas', 'pegawai baru'],
    answer: `**Layanan SPMT (Surat Pernyataan Melaksanakan Tugas)**\n\nPenerbitan dokumen resmi yang menyatakan tanggal mulai efektif seorang pegawai melaksanakan tugas. Dokumen ini merupakan syarat utama pembayaran gaji bagi pegawai baru atau pindahan.${contactInfo(ADMINS.GEDE)}`,
  },
];