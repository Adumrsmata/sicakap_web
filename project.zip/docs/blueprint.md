# **App Name**: SiCakap

## Core Features:

- Employee Identity Verification: Securely capture user NIP and name to personalize the staffing assistance session.
- AI Document Analyzer: An intelligent tool that uses generative AI to analyze uploaded staffing documents (PDF/images) and answer specific questions based on their content.
- Intelligent Knowledge Matching: Automated matching system that scans keywords and FAQ entries to provide instant answers on promotion, study leave, and staffing regulations.
- Interactive Service Menu: A quick-access bottom menu that allows users to select predefined staffing topics and categories easily.
- Persistent Conversation Storage: Store all user inquiries and AI responses in a database for administrative review and continuity across sessions.
- Multimedia Support: Support for multiple file types including Word docs, Excel spreadsheets, and image uploads for document verification.
- Staffing Progress Indicators: Visual status updates and typing animations to keep users engaged while processing document data.

## Style Guidelines:

- Primary color: Modern Healthcare Blue (#1A73E8) conveying trust and clarity. Based on the concept of medical professionalism.
- Background color: A clean, desaturated Pale Sky Blue (#F0F4F8) for a serene and professional hospital-like atmosphere.
- Accent color: Analogous Indigo (#7971D5) used for focus points and interactive file previews, offering clear contrast without being distracting.
- Body and Headline font: 'Poppins' for its contemporary, geometric, and high-clarity sans-serif classification, perfect for administrative interfaces.
- Clean, line-based icons from 'lucide-react' to represent documents, sends, and attachments with a precise, machined feel.
- A focused, center-aligned chat layout with a high-end card container and subtle shadowing typical of premium enterprise portals.
- Fluid 'fade-in' transitions for chat bubbles and a synchronized 'pulse' indicator for the virtual assistant status.