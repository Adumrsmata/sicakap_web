"use client"

import { useState, useEffect, useRef } from 'react';
import { ChatMessage as MessageType, UserIdentity, KNOWLEDGE_BASE } from '@/lib/types';
import ChatMessage from '@/components/chat/ChatMessage';
import IdentityForm from '@/components/chat/IdentityForm';
import ServiceMenu from '@/components/chat/ServiceMenu';
import { aiDocumentAnalysis } from '@/ai/flows/ai-document-analysis-flow';
import { intelligentQueryAnswering } from '@/ai/flows/intelligent-query-answering-flow';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { 
  Send, 
  Loader2, 
  Paperclip, 
  X, 
  FileText, 
  LogOut,
  MoreVertical
} from 'lucide-react';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';

const GREETING = (nama: string) => `Selamat datang di SiCakap, Bapak/Ibu ${nama}! 👋\n\nSaya adalah Asisten Virtual Kepegawaian RS Mata Bali Mandara. Saya siap membantu Bapak/Ibu dengan informasi seputar kenaikan pangkat, tugas belajar, cuti, atau menganalisis dokumen kepegawaian Anda.\n\nSilakan ketik pertanyaan Anda atau pilih layanan di bawah ini.`;

export default function ChatbotPage() {
  const [identity, setIdentity] = useState<UserIdentity | null>(null);
  const [messages, setMessages] = useState<MessageType[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ name: string; dataUri: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const logoData = PlaceHolderImages.find(img => img.id === 'rsmbm-logo');
  const logoUrl = logoData?.imageUrl || 'https://picsum.photos/seed/rsmbm1/400/400';

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleIdentitySubmit = (user: UserIdentity) => {
    setIdentity(user);
    setMessages([
      { role: 'bot', content: GREETING(user.nama), timestamp: new Date().toISOString() }
    ]);
  };

  const toBase64 = (file: File): Promise<string> => 
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const dataUri = await toBase64(file);
      setAttachedFile({ name: file.name, dataUri });
    } catch (err) {
      console.error("File upload error", err);
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const sendMessage = async (text: string) => {
    const content = text.trim();
    if (!content && !attachedFile) return;
    if (loading) return;

    const currentInput = content;
    const currentFile = attachedFile;

    setInput('');
    setAttachedFile(null);
    setLoading(true);

    const userMsg: MessageType = {
      role: 'user',
      content: currentInput || `[Dokumen: ${currentFile?.name}]`,
      timestamp: new Date().toISOString(),
      ...(currentFile ? { file_name: currentFile.name } : {}),
    };

    setMessages(prev => [...prev, userMsg]);

    try {
      let botResponse = '';
      
      const lowerText = currentInput.toLowerCase();
      const matchedKB = KNOWLEDGE_BASE.find(kb => kb.keywords.some(k => lowerText.includes(k)));

      if (matchedKB && !currentFile) {
        botResponse = matchedKB.answer;
      } else if (currentFile) {
        const result = await aiDocumentAnalysis({
          fileDataUri: currentFile.dataUri,
          question: currentInput || "Jelaskan isi dokumen ini secara singkat."
        });
        botResponse = result.answer;
      } else {
        const result = await intelligentQueryAnswering({
          question: currentInput,
          userName: identity?.nama || 'Pegawai'
        });
        botResponse = result.answer;
      }

      setMessages(prev => [...prev, {
        role: 'bot',
        content: botResponse,
        timestamp: new Date().toISOString()
      }]);
    } catch (error) {
      console.error("AI Error", error);
      setMessages(prev => [...prev, {
        role: 'bot',
        content: "Maaf, terjadi gangguan saat memproses permintaan Bapak/Ibu. Silakan coba beberapa saat lagi atau hubungi petugas Kepegawaian RS Mata Bali Mandara secara langsung. 🙏",
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setLoading(false);
    }
  };

  if (!identity) {
    return (
      <main className="min-h-screen flex items-center justify-center p-4 bg-background">
        <div className="w-full max-w-md bg-white rounded-3xl shadow-xl overflow-hidden border border-border/50 animate-in fade-in zoom-in duration-300">
          <div className="bg-primary p-8 text-white relative overflow-hidden">
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4 shadow-lg overflow-hidden p-2">
                <img 
                  src={logoUrl} 
                  alt="RS Mata Bali Mandara" 
                  className="w-full h-full object-contain"
                  data-ai-hint="hospital logo"
                />
              </div>
              <h2 className="text-2xl font-bold tracking-tight text-center">SiCakap</h2>
              <p className="text-white/80 text-sm font-medium">Virtual Staffing Assistant</p>
            </div>
            <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/10 rounded-full blur-2xl" />
            <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-accent/20 rounded-full blur-2xl" />
          </div>
          <IdentityForm onSubmit={handleIdentitySubmit} />
        </div>
      </main>
    );
  }

  return (
    <main className="fixed inset-0 bg-background flex flex-col items-center md:py-6 overflow-hidden">
      <div className="w-full max-w-2xl flex-1 flex flex-col bg-white md:rounded-3xl shadow-2xl border-x md:border border-border/50 relative overflow-hidden transition-all duration-300">
        
        <header className="px-5 py-3 md:py-4 bg-white/80 backdrop-blur-md border-b border-border/50 flex items-center justify-between shrink-0 z-20">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 md:w-11 md:h-11 rounded-2xl bg-primary/10 flex items-center justify-center overflow-hidden border border-primary/20 p-1 shadow-sm">
                <img 
                  src={logoUrl} 
                  alt="Logo RSMBM" 
                  className="w-full h-full object-contain"
                  data-ai-hint="hospital logo"
                />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 md:w-3.5 md:h-3.5 bg-green-500 border-2 border-white rounded-full shadow-sm" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
                SiCakap
                <span className="hidden xs:inline-block px-1.5 py-0.5 rounded-full bg-primary/10 text-primary text-[9px] font-bold uppercase tracking-wider">Online</span>
              </h2>
              <p className="text-[10px] md:text-[11px] text-muted-foreground font-medium truncate max-w-[150px] xs:max-w-none">
                {identity.nama}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-2 hover:bg-muted rounded-full transition-colors text-muted-foreground active:scale-90">
                  <MoreVertical className="w-5 h-5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="rounded-2xl border-border shadow-xl p-1.5">
                <DropdownMenuItem onClick={() => setIdentity(null)} className="text-destructive gap-2 rounded-xl focus:bg-destructive/10 focus:text-destructive cursor-pointer py-2.5">
                  <LogOut className="w-4 h-4" /> Keluar Sesi
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5 scroll-smooth bg-[#F8FAFC]">
          {messages.map((msg, i) => (
            <ChatMessage key={i} message={msg} />
          ))}
          
          {loading && (
            <div className="flex gap-3 animate-in slide-in-from-left-2 fade-in duration-300">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 border border-primary/20">
                 <Loader2 className="w-4 h-4 text-primary animate-spin" />
              </div>
              <div className="bg-white border border-border/60 px-4 py-3 rounded-2xl rounded-tl-sm shadow-sm">
                <div className="flex gap-1.5 items-center">
                  <span className="w-1.5 h-1.5 bg-primary/40 rounded-full typing-dot" style={{ animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 bg-primary/40 rounded-full typing-dot" style={{ animationDelay: '200ms' }} />
                  <span className="w-1.5 h-1.5 bg-primary/40 rounded-full typing-dot" style={{ animationDelay: '400ms' }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <ServiceMenu onSelect={sendMessage} disabled={loading} />

        <footer className="p-3 md:p-4 bg-white border-t border-border space-y-2 shrink-0 z-20">
          {attachedFile && (
            <div className="flex items-center gap-2 px-3 py-2 bg-accent/5 border border-accent/20 rounded-xl text-xs font-medium text-accent animate-in slide-in-from-bottom-2 fade-in">
              <FileText className="w-4 h-4 flex-shrink-0" />
              <span className="flex-1 truncate">{attachedFile.name}</span>
              <button 
                onClick={() => setAttachedFile(null)} 
                className="hover:text-destructive transition-colors p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          <form 
            onSubmit={(e) => { e.preventDefault(); sendMessage(input); }}
            className="flex items-center gap-2"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.xlsx,.xls"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={loading}
              className="w-10 h-10 md:w-11 md:h-11 flex items-center justify-center rounded-2xl border border-border bg-muted/30 text-muted-foreground hover:bg-muted hover:text-primary transition-all flex-shrink-0 disabled:opacity-50 active:scale-90"
            >
              <Paperclip className="w-5 h-5" />
            </button>
            
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ketik pertanyaan..."
              className="flex-1 h-10 md:h-11 px-4 bg-muted/40 border border-border/50 rounded-2xl text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all disabled:opacity-50"
              disabled={loading}
            />
            
            <button
              type="submit"
              disabled={(!input.trim() && !attachedFile) || loading}
              className="w-10 h-10 md:w-11 md:h-11 flex items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/20 hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100 flex-shrink-0"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
          
          <div className="text-center pt-1">
             <p className="text-[8px] md:text-[9px] text-muted-foreground font-medium uppercase tracking-widest opacity-60">RS Mata Bali Mandara • e-Kepegawaian 2024</p>
          </div>
        </footer>
      </div>
    </main>
  );
}
