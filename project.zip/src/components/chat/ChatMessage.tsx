"use client"

import { useState, useEffect } from 'react';
import { ChatMessage as MessageType } from '@/lib/types';
import { cn } from '@/lib/utils';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { FileText, User, ExternalLink } from 'lucide-react';

interface ChatMessageProps {
  message: MessageType;
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const [mounted, setMounted] = useState(false);
  const isBot = message.role === 'bot';
  
  const logoData = PlaceHolderImages.find(img => img.id === 'rsmbm-logo');
  const logoUrl = logoData?.imageUrl || 'https://picsum.photos/seed/rsmbm1/400/400';

  useEffect(() => {
    setMounted(true);
  }, []);

  // Function to parse [text](url) markdown-style links
  const renderContent = (content: string) => {
    const parts = content.split(/(\[.*?\]\(.*?\))/g);
    return parts.map((part, index) => {
      const match = part.match(/\[(.*?)\]\((.*?)\)/);
      if (match) {
        const isWhatsApp = match[2].includes('wa.me');
        return (
          <a 
            key={index} 
            href={match[2]} 
            target="_blank" 
            rel="noopener noreferrer"
            className={cn(
              "inline-flex items-center gap-1 font-bold underline decoration-2 underline-offset-2 transition-all hover:opacity-80",
              isBot ? "text-primary" : "text-white"
            )}
          >
            {match[1]}
            <ExternalLink className="w-3 h-3" />
          </a>
        );
      }
      return part;
    });
  };

  const formatTime = (timestamp: string) => {
    if (!mounted) return '--:--';
    try {
      return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return '--:--';
    }
  };

  return (
    <div className={cn(
      "flex w-full gap-3 fade-in",
      isBot ? "justify-start" : "justify-end"
    )}>
      {isBot && (
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden flex-shrink-0 border border-primary/20 p-0.5">
          <img 
            src={logoUrl} 
            alt="SiCakap Logo" 
            className="w-full h-full object-contain"
            data-ai-hint="hospital logo"
          />
        </div>
      )}

      <div className={cn(
        "max-w-[85%] sm:max-w-[70%] space-y-1",
        !isBot && "text-right"
      )}>
        <div className={cn(
          "px-4 py-3 rounded-2xl chat-bubble-shadow text-sm leading-relaxed",
          isBot 
            ? "bg-white text-foreground rounded-tl-none border border-border" 
            : "bg-primary text-primary-foreground rounded-tr-none shadow-blue-500/20"
        )}>
          {message.file_name && (
            <div className={cn(
              "flex items-center gap-2 mb-2 p-2 rounded-lg text-xs font-medium border",
              isBot ? "bg-muted/50 border-border" : "bg-white/10 border-white/20 text-white"
            )}>
              <FileText className="w-4 h-4 flex-shrink-0" />
              <span className="truncate">{message.file_name}</span>
            </div>
          )}
          
          <div className="whitespace-pre-wrap break-words">
            {renderContent(message.content)}
          </div>
        </div>
        
        <div className="flex items-center gap-1 px-1">
          {!isBot && <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">Anda</span>}
          {isBot && <span className="text-[10px] text-primary font-medium uppercase tracking-wider">SiCakap</span>}
          <span className="text-[10px] text-muted-foreground opacity-60">•</span>
          <span className="text-[10px] text-muted-foreground opacity-60">
            {formatTime(message.timestamp)}
          </span>
        </div>
      </div>

      {!isBot && (
        <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 border border-accent/20">
          <User className="w-4 h-4 text-accent" />
        </div>
      )}
    </div>
  );
}