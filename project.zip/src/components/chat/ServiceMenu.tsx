"use client"

import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { 
  Briefcase, 
  GraduationCap, 
  CalendarDays, 
  FileCheck, 
  Info,
  Clock,
  LayoutGrid,
  ChevronUp,
  UserCheck,
  CreditCard,
  FileText,
  Monitor,
  Stethoscope,
  Award,
  BookOpen,
  FileSignature
} from 'lucide-react';

interface ServiceMenuProps {
  onSelect: (text: string) => void;
  disabled?: boolean;
}

const SERVICES = [
  { id: 'pangkat', label: 'Layanan Kenaikan Pangkat', icon: Briefcase, color: 'bg-blue-100 text-blue-600' },
  { id: 'fungsional', label: 'Kenaikan Pangkat Fungsional', icon: Award, color: 'bg-indigo-100 text-indigo-600' },
  { id: 'belajar', label: 'Layanan Tugas Belajar', icon: GraduationCap, color: 'bg-purple-100 text-purple-600' },
  { id: 'karis', label: 'Layanan Karis/Karsu', icon: CreditCard, color: 'bg-pink-100 text-pink-600' },
  { id: 'pensiun', label: 'Layanan Usulan Pensiun', icon: UserCheck, color: 'bg-orange-100 text-orange-600' },
  { id: 'cuti', label: 'Layanan Cuti Pegawai', icon: CalendarDays, color: 'bg-emerald-100 text-emerald-600' },
  { id: 'gelar', label: 'Layanan Pencantuman Gelar', icon: BookOpen, color: 'bg-cyan-100 text-cyan-600' },
  { id: 'simpeg', label: 'Layanan SIMPEG/SIPERI', icon: Monitor, color: 'bg-slate-100 text-slate-600' },
  { id: 'sisdmk', label: 'Layanan SISDMK', icon: Stethoscope, color: 'bg-teal-100 text-teal-600' },
  { id: 'ukom', label: 'Layanan Uji Kompetensi JFK', icon: FileCheck, color: 'bg-amber-100 text-amber-600' },
  { id: 'kgb', label: 'Layanan KGB/TPP', icon: Clock, color: 'bg-rose-100 text-rose-600' },
  { id: 'spmt', label: 'Layanan SPMT', icon: FileSignature, color: 'bg-lime-100 text-lime-600' },
  { id: 'tugas', label: 'Layanan Surat Tugas', icon: FileText, color: 'bg-violet-100 text-violet-600' },
  { id: 'siasn', label: 'Layanan SI-ASN', icon: Monitor, color: 'bg-blue-100 text-blue-700' },
  { id: 'modelc', label: 'Layanan Model C', icon: Info, color: 'bg-gray-100 text-gray-600' },
  { id: 'slks', label: 'Layanan SLKS', icon: Award, color: 'bg-yellow-100 text-yellow-600' },
  { id: 'ecuti', label: 'Layanan E-Cuti', icon: CalendarDays, color: 'bg-green-100 text-green-600' },
];

export default function ServiceMenu({ onSelect, disabled }: ServiceMenuProps) {
  return (
    <div className="px-4 py-2 bg-white border-t border-border/30 flex justify-center shrink-0">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="outline" 
            disabled={disabled}
            className="w-full max-w-sm rounded-xl gap-2 text-xs font-bold shadow-sm border-primary/20 text-primary hover:bg-primary/5 h-10 transition-all active:scale-95"
          >
            <LayoutGrid className="w-4 h-4" />
            Menu Layanan Kepegawaian (17 Layanan)
            <ChevronUp className="ml-auto w-4 h-4 opacity-50" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent 
          align="center" 
          side="top" 
          className="w-[280px] sm:w-[350px] rounded-2xl p-0 shadow-2xl border-border/50 mb-2 overflow-hidden"
        >
          <div className="px-4 py-3 bg-muted/30 border-b border-border/50">
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Pilih Layanan Cepat</p>
          </div>
          
          <ScrollArea className="h-[350px]">
            <div className="p-2 grid grid-cols-1 gap-1">
              {SERVICES.map((service) => (
                <DropdownMenuItem 
                  key={service.id} 
                  onClick={() => onSelect(service.label)}
                  className="rounded-xl py-2.5 px-3 gap-3 cursor-pointer focus:bg-primary/5 focus:text-primary transition-colors group"
                >
                  <div className={cn("p-2 rounded-lg transition-transform group-hover:scale-110", service.color)}>
                    <service.icon className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="font-semibold text-xs">{service.label}</span>
                    <span className="text-[9px] text-muted-foreground">Klik untuk informasi detail</span>
                  </div>
                </DropdownMenuItem>
              ))}
            </div>
          </ScrollArea>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
