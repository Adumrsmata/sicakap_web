import { config } from 'dotenv';
config();

import '@/ai/flows/ai-document-analysis-flow.ts';
import '@/ai/flows/intelligent-query-answering-flow.ts';