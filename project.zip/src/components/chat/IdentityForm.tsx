"use client"

import { useState } from 'react';
import { UserIdentity } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CardContent } from '@/components/ui/card';
import { User, CreditCard, ArrowRight } from 'lucide-react';

interface IdentityFormProps {
  onSubmit: (identity: UserIdentity) => void;
}

export default function IdentityForm({ onSubmit }: IdentityFormProps) {
  const [nama, setNama] = useState('');
  const [nip, setNip] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (nama.trim() && nip.trim()) {
      onSubmit({ nama, nip });
    }
  };

  return (
    <CardContent className="p-8 space-y-6 flex flex-col justify-center min-h-[400px]">
      <div className="text-center space-y-2 mb-4">
        <h1 className="text-2xl font-bold text-primary">Verifikasi Identitas</h1>
        <p className="text-muted-foreground text-sm">
          Silakan masukkan Nama dan NIP Anda untuk memulai percakapan dengan SiCakap.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="space-y-2">
          <Label htmlFor="nama" className="text-sm font-semibold flex items-center gap-2">
            <User className="w-4 h-4 text-primary" /> Nama Lengkap
          </Label>
          <Input
            id="nama"
            value={nama}
            onChange={(e) => setNama(e.target.value)}
            placeholder="Contoh: Dr. I Wayan Sudiarta"
            className="h-12 border-muted focus:border-primary transition-all rounded-xl"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="nip" className="text-sm font-semibold flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-primary" /> NIP (Nomor Induk Pegawai)
          </Label>
          <Input
            id="nip"
            value={nip}
            onChange={(e) => setNip(e.target.value)}
            placeholder="18 digit angka NIP"
            className="h-12 border-muted focus:border-primary transition-all rounded-xl"
            required
          />
        </div>

        <Button 
          type="submit" 
          className="w-full h-12 text-base font-semibold rounded-xl bg-primary hover:bg-primary/90 shadow-md group transition-all"
          disabled={!nama || !nip}
        >
          Masuk Sekarang
          <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </Button>
      </form>

      <div className="pt-4 text-center">
        <p className="text-xs text-muted-foreground">
          Informasi Anda terjamin kerahasiaannya dan hanya digunakan untuk layanan kepegawaian internal.
        </p>
      </div>
    </CardContent>
  );
}
