'use server';
/**
 * @fileOverview An AI agent that provides helpful and contextually relevant answers or next steps for staffing-related questions.
 *
 * - intelligentQueryAnswering - A function that handles the intelligent query answering process.
 * - IntelligentQueryAnsweringInput - The input type for the intelligentQueryAnswering function.
 * - IntelligentQueryAnsweringOutput - The return type for the intelligentQueryAnswering function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const IntelligentQueryAnsweringInputSchema = z.object({
  question: z.string().describe('The user\'s question about staffing.'),
  userName: z.string().describe('The name of the user asking the question.'),
});
export type IntelligentQueryAnsweringInput = z.infer<typeof IntelligentQueryAnsweringInputSchema>;

const IntelligentQueryAnsweringOutputSchema = z.object({
  answer: z.string().describe('A helpful and contextually relevant answer or suggested next steps.'),
});
export type IntelligentQueryAnsweringOutput = z.infer<typeof IntelligentQueryAnsweringOutputSchema>;

export async function intelligentQueryAnswering(input: IntelligentQueryAnsweringInput): Promise<IntelligentQueryAnsweringOutput> {
  return intelligentQueryAnsweringFlow(input);
}

const prompt = ai.definePrompt({
  name: 'intelligentQueryAnsweringPrompt',
  input: { schema: IntelligentQueryAnsweringInputSchema },
  output: { schema: IntelligentQueryAnsweringOutputSchema },
  prompt: `You are SiCakap, an empathetic and helpful virtual staffing assistant for RS Mata Bali Mandara. Your goal is to provide clear, concise, and friendly answers to employee questions about staffing in Indonesian.

If you don't have a specific answer, you MUST refer the user to the correct admin based on the following mapping:

1. Kenaikan Pangkat Fungsional, Tugas Belajar, Karis/Karsu, Usulan Pensiun, Pencantuman Gelar, Model C, SLKS:
   Admin: I Nyoman Jaya Merta (087862206937)

2. Layanan Kenaikan Pangkat (Reguler), SI-ASN:
   Admin: Ni Nyoman Suwari (0895601305041)

3. Cuti Pegawai, KGB/TPP, Surat Tugas, E-Cuti:
   Admin: Santy Pattawari (085337812997)

4. SIMPEG/SIPERI:
   Admin: Shri Padmayani (082257607892)

5. SISDMK, Uji Kompetensi JFK, SPMT:
   Admin: Gede Mahendra Arya Wiguna Pangestu (082138740446)

Instructions:
- Always be polite and professional.
- Use Indonesian language.
- Format telephone numbers so they are clickable (e.g., [Nomor](https://wa.me/62...)).
- If the topic isn't listed, suggest contacting the HR department generally.

User's Name: {{{userName}}}
User's Question: "{{{question}}}"

Based on the above, please provide a response:`,
});

const intelligentQueryAnsweringFlow = ai.defineFlow(
  {
    name: 'intelligentQueryAnsweringFlow',
    inputSchema: IntelligentQueryAnsweringInputSchema,
    outputSchema: IntelligentQueryAnsweringOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
